import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.logging.Level;

import org.apache.commons.httpclient.NameValuePair;
import org.xml.sax.Attributes;

import com.gargoylesoftware.htmlunit.*;





/**
 * Robot for handling HTML calls
 * @author Cromano
 *
 */
public class HTMLRobot extends Robot {

	//the WebClient used for all of this HTMLRobot's operations
	private WebClient htmlRobotClient;
	private long requestTime;
	//The ArrayList of NameValuePairs to be used in the next POST operation
	private ArrayList<NameValuePair> postList;
	private TopLevelWindow basicHtmlRobotWindow;
	private WebResponse htmlRobotResponse;
	private WebRequestSettings htmlRobotSettings;
	private String browserType;
	private static boolean ignoreOutsideContent;
	private boolean javaScriptEnabled;
	private boolean redirectEnabled;
	private boolean throwExceptionOnScriptError;
	private int cacheSize;
	private boolean useInsecureSSL;
	private boolean popupBlockerEnabled;
	private boolean throwExceptionOnFailingStatusCode;
	private boolean printContentOnFailingStatusCode;
	private PageCreator htmlRobotPageCreator;
	private int totalStepBytes;
	private BrowserVersion htmlRobotBrowserVersion;
	private String proxyHost;
	private int proxyPort;
	private boolean shouldReconfigureRobotClient;
	private boolean shouldReloadRobotClient;

	
	//Permitted actions that the robot is capable of performing
	private static enum ActionTypes {
		
		GET,
		POST,
		VERIFY,
		WAIT
		
	}
	
	/**
	 * Constructor defines the location of the XML RobotScript. All other variables will be
	 * set to default settings
	 * 
	 * @param inputLocation The location of the script log
	 */
	public HTMLRobot(String scriptLogLocation){
		super(scriptLogLocation);
		
		postList = new ArrayList<NameValuePair>();
		requestTime = 0;
		setDefaultHTMLRobotPreferences();
		//Too much trouble to place default BrowserVersion in prefs
		htmlRobotBrowserVersion = BrowserVersion.INTERNET_EXPLORER_7_0;

	}
	
	/**
	 * Constructor defines the locations of the robot script, result, error, and console logs
	 * 
	 * @param scriptLogLocation The location of the script log
	 * @param prefsLocation The location of the preferences file
	 */
	public HTMLRobot(String scriptLogLocation, String prefsLocation){
		super(scriptLogLocation, prefsLocation);
		
		postList = new ArrayList<NameValuePair>();
		requestTime = 0;
		setDefaultHTMLRobotPreferences();
		//Too much trouble to place default BrowserVersion in prefs
		htmlRobotBrowserVersion = BrowserVersion.INTERNET_EXPLORER_7_0;
		
	}
	
	/**
	 * Configures the WebClient with the preferences saved in the class fields
	 */
	private void configureHtmlRobotClient() {
		
		htmlRobotClient.setJavaScriptEnabled(javaScriptEnabled);
		htmlRobotClient.setRedirectEnabled(redirectEnabled);
		htmlRobotClient.setPopupBlockerEnabled(popupBlockerEnabled);
		try {
			htmlRobotClient.setUseInsecureSSL(useInsecureSSL);
		} catch (GeneralSecurityException e) {

			errorLog.log(Level.SEVERE, "Security Exception during configuration.");
			e.printStackTrace();
		}
		//Should be set by the loadGenerator
		//WebClient.setIgnoreOutsideContent(ignoreOutsideContent);
		htmlRobotClient.setThrowExceptionOnFailingStatusCode(throwExceptionOnFailingStatusCode);
		htmlRobotClient.setThrowExceptionOnScriptError(throwExceptionOnScriptError);
		htmlRobotClient.setPrintContentOnFailingStatusCode(printContentOnFailingStatusCode);
		htmlRobotClient.setTimeout(defaultTimeout);
		htmlRobotClient.setCurrentWindow(basicHtmlRobotWindow);
		htmlRobotClient.setPageCreator(htmlRobotPageCreator);
		
	}
	
	/**
	 * Loads the preferences specific to an HTMLRobot
	 */
	private void setDefaultHTMLRobotPreferences() {
		
		browserType = robotPreferences.getString("defaultBrowserType");
		ignoreOutsideContent = Boolean.parseBoolean(robotPreferences.getString("defaultIgnoreOutsideContent"));
		javaScriptEnabled = Boolean.parseBoolean(robotPreferences.getString("defaultJavaScriptEnabled"));
		popupBlockerEnabled = Boolean.parseBoolean(robotPreferences.getString("defaultPopupBlockerEnabled"));
		redirectEnabled = Boolean.parseBoolean(robotPreferences.getString("defaultRedirectEnabled"));
		throwExceptionOnFailingStatusCode = Boolean.parseBoolean(robotPreferences.getString("defaultThrowExceptionOnFailingStatusCode"));
		throwExceptionOnScriptError = Boolean.parseBoolean(robotPreferences.getString("defaultThrowExceptionOnScriptError"));
		useInsecureSSL = Boolean.parseBoolean(robotPreferences.getString("defaultUseInsecureSSL"));
		cacheSize = Integer.parseInt(robotPreferences.getString("defaultCacheSize"));
		printContentOnFailingStatusCode = Boolean.parseBoolean(robotPreferences.getString("defaultPrintContentOnFailingStatusCode"));
		proxyHost = robotPreferences.getString("defaultProxyHost");
		proxyPort = Integer.parseInt(robotPreferences.getString("defaultProxyPort"));
		
	}
	
	/**
	 * Executes a step passed in with its attributes
	 * 
	 * @param actionType The enum ActionTypes to be executed
	 * @param action The encoded action information
	 */
	private boolean executeScriptStep(ActionTypes stepType, Attributes actionAttributes) {

		boolean tempReturnStatus = false;
		
		switch (stepType) {
		case GET:
			//Get the page and any resources
			//Return a success or fail
			//TODO
			break;
		case POST:
			//Post the information to a page
			//Return a success or fail
			//TODO
			break;
		case VERIFY:
			//Check for some appropriate information
			//Return a success or fail
			//TODO
			break;
		case WAIT:
			//Wait for the given amount of time
			//BEWARE - the index of the wait length may change as the script format is developed
			if (actionAttributes.getValue(0).equals("")) {
				try {
					this.wait(defaultWaitStep);
				} catch (InterruptedException e) {
					errorLog.log(Level.SEVERE, "Interrupted Exception during a default WAIT step");
					e.printStackTrace();
				}
			} else {
				try {
					this.wait(Integer.parseInt(actionAttributes.getValue(0)));
				} catch (NumberFormatException e) {
					errorLog.log(Level.SEVERE, "Could not determine the wait length during a WAIT Step");
					e.printStackTrace();
				} catch (InterruptedException e) {
					errorLog.log(Level.SEVERE, "Interrupted Exception during a WAIT step");
					e.printStackTrace();
				}
			}
			break;
		default:
			//Nothing should read this code unless there is a bad script step
			//Everything should have a particular ScriptStep to execute
			errorLog.log(Level.SEVERE, "A Bad Step was taken.");
		break;

		}
		//Only reachable by WAIT step or error
		return tempReturnStatus;
		
	}
	
	/**
	 * Retrieves the accumulated amount of time to load all of the requested page and resources so far
	 * @return The accumulated time performing a step
	 */
	private long getLoadTime() {
		return requestTime;
	}
	
	/**
	 * Requests a page with the current settings
	 * 
	 * @param window The window to be used for the GET
	 * @param request The settings to be used for the GET
	 * @return The page retrieved by the GET
	 * @throws Exception
	 */
/*	private Page getPage(WebWindow window, WebRequestSettings request) throws Exception {
		Long tempTime = System.currentTimeMillis();
		Page page = htmlRobotClient.getPage(window,request);
		requestTime = System.currentTimeMillis() - tempTime;
		return page;
	}*/
	
/*	public Page postPage(WebWindow window, WebRequestSettings request) {
		
		Long tempTime = System.currentTimeMillis();
		//Page page = htmlRobotClient.loadWebResponseInto(webResponse, htmlRobotWindow)
		
	}*/
	
	/**
	 * Collects the parameters to be passed in the next POST operation
	 * 
	 * @param name The name of the parameter to be posted
	 * @param value The value of the parameter to be posted
	 */
	private void addInputParameter(String name, String value) {

			postList.add(new NameValuePair(name,value));

	}
	
	/**
	 * Clears the list of input parameters for the next POST operation
	 */
	private void clearInputParameters() {
		postList.clear();
	}
	
	/**
	 * The primary method of any robot
	 * This method will load the settings from the settings file, then parse the script
	 * 
	 */
	public void runRobot() throws IOException {

		currentElement = "";
		//True is a success, false is a failure
		//WAIT steps are not counted and VERIFY steps are uncertain
		boolean stepReturnStatus = false;
		Attributes stepAttributes = null;
		Long tempTime;
		int tempAmount;

		//TODO
		//Read/Parse Header
		//Configure the fields from the Header settings
		
		if (proxyHost == null) {
			htmlRobotClient = new WebClient(htmlRobotBrowserVersion);
		} else {
			htmlRobotClient = new WebClient(htmlRobotBrowserVersion, proxyHost, proxyPort);
		}
		
		configureHtmlRobotClient();
		
		//Begin the step loop
		while(scriptReader.ready()) {

			if(shouldReloadRobotClient) {
				if (proxyHost == null) {
					htmlRobotClient = new WebClient(htmlRobotBrowserVersion);
				} else {
					htmlRobotClient = new WebClient(htmlRobotBrowserVersion, proxyHost, proxyPort);
				}
			} else if (shouldReconfigureRobotClient) {
				configureHtmlRobotClient();
			}

			
			//Each XML element will be a step with some attributes
			//(These steps are HTML Robot specific, but the idea remains the same
			//A GET element will have all the relevant information
			//A POST element will have all the relevant information to send
			//A VERIFY element may or may not be equivalent to a unique step
			//A WAIT element will have one attribute (the time to wait in milliseconds)

			//Log the return status if the Step was a GET, POST, or VERIFY in resultsLog
			stepReturnStatus = executeScriptStep(ActionTypes.valueOf(currentElement), stepAttributes);
			
			//Log the retrievaltime
			tempTime = getLoadTime();
			
			//Log the raw data amount transferred
			tempAmount = getTotalStepBytes();

		}
		
		//TODO
		//Perform closing operations
		//Close resultsLog
		//Close input and output streams if necessary
		
	}

	/**
	 * Retrieve the accumulated bytes from a steps transfers
	 * @return The accumulated bytes from a step
	 */
	private int getTotalStepBytes() {
		return totalStepBytes;
	}
	
}
