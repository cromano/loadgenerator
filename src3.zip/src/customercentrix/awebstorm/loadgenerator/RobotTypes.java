package customercentrix.awebstorm.loadgenerator;

public enum RobotTypes {

	HTMLRobot
	
}
