package customercentrix.awebstorm.loadgenerator;

import java.net.URI;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import customercentrix.awebstorm.loadgenerator.robot.HTMLRobot;
import customercentrix.awebstorm.loadgenerator.robot.Robot;

/**
 * Main class for the loadgenerator slaves. Performs system scan for optimization and 
 * then queries the Scheduler for Robot Scripts. Each Robot Script is handed to a 
 * Robot thread of the necessary subclass. Also, capable of returning results to 
 * the Scheduler.
 * 
 * @author Cromano
 * @version 1.0
 *
 */
public class LoadGeneratorImpl implements LoadGenerator {

	private static Logger consoleLog;
	private static Logger resultLog;
	private static Logger errorLog;
	
	/**
	 * Main method constructs a new LoadGeneratorImpl and calls run() on it 
	 * @param args Console parsing not functional
	 */
	public static void main(String[] args) {
		//TODO
		//May add a console parser later
		new LoadGeneratorImpl().run();
		
	}
	
	/**
	 * Configures the 3 logs used by loadgenerator and its robots
	 * 
	 * @param configLocation The location of the configuration file
	 */
	public void configureLogs( String configLocation ) {
		
		consoleLog = Logger.getLogger("loadgenerator.log.consoleLog");
		resultLog = Logger.getLogger("loadgenerator.log.resultLog");
		errorLog = Logger.getLogger("loadgenerator.log.errorLog");
		PropertyConfigurator.configureAndWatch(configLocation);
		
		if( consoleLog.isDebugEnabled()) {
			consoleLog.debug("Logs configured.");
		}
		
	}

	@Override
	public URI getSchedulerURI() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void optimize() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void retrieveScripts() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendLogs() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void syncWithScheduler() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void systemScan() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createRobot(String ScriptLocation, String prefsLocation) {
		// TODO Auto-generated method stub
		//RobotChooser chooser = new RobotChooser();
		
		if( consoleLog.isDebugEnabled()) {
			consoleLog.debug("Creating new Robot: " + ScriptLocation);
		}
		
		Thread newRobot = selectRobotType(ScriptLocation, prefsLocation);
		
		//May not be the best way to handle a bad robotType
		if (newRobot != null) {
			newRobot.setName(ScriptLocation);
			newRobot.run();
		} else {
			//TODO - clean up scripts and left unused info
			errorLog.warn("Bad robotType found for: " + ScriptLocation);
		}
		
	}

	@Override
	public void loadPreferences(String prefsLocation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run() {
		
		if ( consoleLog.isDebugEnabled() ) {
			consoleLog.debug("Starting Load Generator");
		}
		
		// TODO Auto-generated method stub
		
		if ( consoleLog.isDebugEnabled() ) {
			consoleLog.debug("Closing Load Generator");
		}
		
	}
	
	private Robot selectRobotType(String scriptLocation, String prefsLocation) {
		// TODO Auto-generated method stub
		
		
		
		RobotTypes robotType = null;
		
		//Parse header
		//set robotType to a particular enum
		switch(robotType) {
		case HTMLRobot:
			return new HTMLRobot(scriptLocation,prefsLocation,consoleLog,resultLog,errorLog);
			
		default:
			//Bad script if this error log is reached
			errorLog.warn("Bad robotType found.");
			break;
		}
		
		return null;
	}
	
	@Override
	public boolean killRobot (String scriptLocation) {
		
		if (consoleLog.isDebugEnabled()) {
			consoleLog.debug("Attempting to kill: " + scriptLocation);
		}
		
		Thread[] tarray = new Thread[100];
		Thread.enumerate(tarray);
		int i = 0;
		while( tarray[i] != null ) {
			
			if (consoleLog.isDebugEnabled()) {
				consoleLog.debug("Robot found, trying to kill it...");
			}
			
			if( scriptLocation.equals(tarray[i].getName()) ) {
				((Robot) tarray[i]).setContinueExecuting(false);
			}
			i++;
		}
		
		return false;
	}

}
