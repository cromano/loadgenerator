package customercentrix.awebstorm.loadgenerator;

import java.net.URI;


/**
 * LoadGenerator Interface
 * 
 * @author Cromano
 * @version 1.0
 *
 */
public interface LoadGenerator {
	
	/**
	 * Run a LoadGenerator 
	 */
	public void run();
	
	/**
	 * Open the loadgenerator configuration file and configure the error, result, and console logs
	 * @param configLocation Location of the LoadGenerator configuration file.
	 */
	public void configureLogs(String configLocation);
	
	/**
	 * Part of an unimplemented requirement of the LoadGenerator to ensure
	 * it is loading into a sustainable architecture.
	 */
	public void systemScan();
	
	/**
	 * Unimplemented optimization constraints that the LoadGenerator may send to the
	 * Scheduler or perform locally.
	 */
	public void optimize();
	
	/**
	 * Unimplemented method to load any preferences or configurations that the
	 * configureLogs() method has not already accomplished.
	 * @param prefsLocation Location of the preferences file
	 */
	public void loadPreferences(String prefsLocation);
	
	
	/**
	 * Can be implemented using a static constant or a configuration value
	 * @return The URI of the Scheduler
	 */
	public URI getSchedulerURI();
	
	/**
	 * Communicates with the scheduler to perform necessary tasks such as 
	 * syncWithScheduler() or sendLogs(). May be implemented to synchronize the
	 * System clock with the server's for additional accuracy.
	 */
	public void syncWithScheduler();
	
	/**
	 * Ask and retrieve Scripts to createRobots with
	 */
	public void retrieveScripts();
	
	/**
	 * Send the necessary logs back to the Scheduler
	 */
	public void sendLogs();
	
	/**
	 * Create a robot
	 * @param ScriptLocation Location of the Robot's Script
	 * @param prefsLocation Location of the Robot's preferences
	 */
	public void createRobot(String scriptLocation,String prefsLocation);
	
	/**
	 * Kill the robot using the specified thread name and Script location
	 * @param scriptLocation The name of the robot's thread
	 * @return True if the robot was asked to die, false if the robot was not found or otherwise unable to be stopped
	 */
	public boolean killRobot(String scriptLocation);
	
}
