import com.gargoylesoftware.htmlunit.*;

public class WebWindowRobot extends WebWindowImpl {

	@Override
	protected boolean isJavaScriptInitializationNeeded() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public WebWindow getParentWindow() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public WebWindow getTopWindow() {
		// TODO Auto-generated method stub
		return null;
	}



}
