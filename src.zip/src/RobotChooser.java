
/**
 * Creates a new Robot based on settings from the RobotScriptLocation
 * @author Cromano
 *
 */
public class RobotChooser {

}
